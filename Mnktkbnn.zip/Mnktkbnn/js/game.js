// alert("Начинаем?")
var cvs = document.getElementById("canvas");
var ctx = cvs.getContext("2d");
var controller;
var loop;

// звуковые файлы
var fly = new Audio();
var score_audio = new Audio();
var gameover = new Audio();
var bit = new Audio();

fly.src = "audios/fly.mp3";
score_audio.src = "audios/score.mp3";
gameover.src = "audios/gameover.mp3";
bit.src = "audios/bit.mp3";

// изображение
var bnn = new Image();
var palm = new Image();
var vagon = new Image();
var mnk = new Image();
var bg2 = new Image();
var bg = new Image();

bnn.src = "images/bnn.png";
palm.src = "images/palm.png";
vagon.src = "images/vagon.png";
mnk.src = "images/mnk.png";
bg2.src = "images/bg2.png";
bg.src = "images/bg.png";

//создание блоков
var drive = [];

drive[0] = {
    x : cvs.width,
    y : 0
}

var anim = [];

anim[0] = {
    x : cvs.width - 288,
    y : 0
}

var score = 0;

// позиция
var xPos = 65;
var yPos = 0;
var grav = 0.9;
var gap = 250;

jump = {
    jumping : true,
    y : 0
}

controller = {

    up:false,
    MouseListener:function(event) {

        var key_state = (event.type == "click")?true:false;

        switch(event.touches) {
            case this.up: // прыжок
                controller.up = key_state;
                break;
        }

    }



};

loop = function() {
    ctx.drawImage(bg, 0, 0);
    bit.play();

    if (controller.up && jump.jumping == false) {

        fly.play();
        yPos -= 50;
        jump.jumping = true;
        controller.up = false;

    }

    yPos += grav;// гравитация
    jump.y += yPos;
    yPos *= 0.9;// трение

    // место бананов
    if (jump.y > 512 - 165) {

        jump.jumping = false;
        jump.y = 512 - 165;
        yPos = 0;

    }

    for(var j = 0; j < anim.length; j++) {

        ctx.drawImage(bg2, anim[j].x, anim[j].y);

        anim[j].x-- ;
        anim[j].x-- ;
        anim[j].x-- ;
        anim[j].x-- ;

        if(anim[j].x == -4) {
            anim.push({
                x : cvs.width,
                y : 0
            });
        }

    }

    ctx.drawImage(mnk, 0, 0);
    ctx.drawImage(bnn, xPos, jump.y);
    ctx.drawImage(vagon, 0 , 0);

    window.requestAnimationFrame(loop);

};

var constant;
var number;

function draw() {

    for(var i = 0; i < drive.length; i++) {

        constant = cvs.height - palm.height;

        ctx.drawImage(palm, drive[i].x, drive[i].y + constant + gap);

        drive[i].x-- ;
        drive[i].x-- ;
        drive[i].x-- ;
        drive[i].x-- ;

        if(drive[i].x == -4) {
            drive.push({
                x : cvs.width,
                y : Math.floor(Math.random() * constant) - constant
            });
        }

        // отслеживание прикосновений
        if(xPos + bnn.width >= drive[i].x
            && xPos <= drive[i].x + palm.width
            && (jump.y + gap <= drive[i].y + constant
                || jump.y + bnn.height >= drive[i].y + constant + gap))
        {

            xPos = drive[i].x;
            jump.y = drive[i].y + constant + gap;

            bit.pause();
            gameover.play();
            gameover.onended = function () {
                window.location.reload() // Перезагрузка страницы
            }
        }

        if(drive[i].x <= 80) {
            score++;
            // score_audio.play();
        }
    }

    ctx.fillStyle = "#000";
    ctx.font = "12px Impact";
    ctx.fillText("Счет: " + score + " метров", 10, cvs.height - 20);

    requestAnimationFrame(draw);
}

cvs.addEventListener("click", controller.MouseListener);
cvs.addEventListener("mousedown", controller.MouseListener);
cvs.addEventListener("mouseup", controller.MouseListener);
window.requestAnimationFrame(loop);
palm.onload = draw;